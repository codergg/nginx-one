package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_tr_TR extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "TRL", "TL" },
            { "TRY", "YTL" },
        };
    }
}
