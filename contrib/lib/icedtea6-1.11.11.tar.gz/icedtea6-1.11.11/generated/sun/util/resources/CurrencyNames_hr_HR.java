package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_hr_HR extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "HRK", "Kn" },
        };
    }
}
