package sun.util.resources;

import java.util.ListResourceBundle;

public final class CalendarData_hi extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
        };
    }
}
