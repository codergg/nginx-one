package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_cs_CZ extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "CZK", "K\u010D" },
        };
    }
}
