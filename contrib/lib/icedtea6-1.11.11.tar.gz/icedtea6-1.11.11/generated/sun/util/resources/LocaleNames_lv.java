package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_lv extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "LV", "Latvija" },
            { "lv", "Latvie\u0161u" },
        };
    }
}
