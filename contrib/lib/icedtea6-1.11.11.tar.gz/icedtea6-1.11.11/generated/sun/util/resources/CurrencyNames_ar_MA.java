package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_MA extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "MAD", "\u062F.\u0645.\u200F" },
        };
    }
}
