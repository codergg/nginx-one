package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_TN extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "TND", "\u062F.\u062A.\u200F" },
        };
    }
}
