package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_bg extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "BG", "\u0411\u044A\u043B\u0433\u0430\u0440\u0438\u044F" },
            { "bg", "\u0431\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438" },
        };
    }
}
