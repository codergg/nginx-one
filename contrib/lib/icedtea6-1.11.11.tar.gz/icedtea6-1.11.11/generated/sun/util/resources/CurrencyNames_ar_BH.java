package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_BH extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "BHD", "\u062F.\u0628.\u200F" },
        };
    }
}
