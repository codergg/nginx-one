package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_th_TH extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "THB", "\u0E3F" },
        };
    }
}
