package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_et extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "EE", "Eesti" },
            { "et", "Eesti" },
        };
    }
}
