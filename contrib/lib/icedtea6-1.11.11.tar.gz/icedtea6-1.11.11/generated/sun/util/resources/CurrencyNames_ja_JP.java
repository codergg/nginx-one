package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ja_JP extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "JPY", "\uFFE5" },
        };
    }
}
