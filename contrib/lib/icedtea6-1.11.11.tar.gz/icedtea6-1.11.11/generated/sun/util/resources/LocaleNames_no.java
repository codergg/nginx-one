package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_no extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "%%B", "bokm\u00E5l" },
            { "%%NY", "nynorsk" },
            { "NO", "Norge" },
            { "no", "norsk" },
        };
    }
}
