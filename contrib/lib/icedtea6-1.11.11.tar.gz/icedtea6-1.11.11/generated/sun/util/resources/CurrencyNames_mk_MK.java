package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_mk_MK extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "MKD", "Den" },
        };
    }
}
