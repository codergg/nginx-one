package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_ro extends LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "RO", "Rom\u00E2nia" },
            { "ro", "rom\u00E2n\u0103" },
        };
    }
}
