package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_sv extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "ALLA" },
            { "CONFIG", "KONFIG" },
            { "FINE", "FIN" },
            { "FINER", "FINARE" },
            { "FINEST", "FINAST" },
            { "INFO", "INFO" },
            { "OFF", "AV" },
            { "SEVERE", "ALLVARLIG" },
            { "WARNING", "VARNING" },
        };
    }
}
