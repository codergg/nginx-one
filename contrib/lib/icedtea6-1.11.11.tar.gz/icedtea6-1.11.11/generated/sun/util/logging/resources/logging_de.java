package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_de extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "ALLE" },
            { "CONFIG", "KONFIG" },
            { "FINE", "FEIN" },
            { "FINER", "FEINER" },
            { "FINEST", "AM FEINSTEN" },
            { "INFO", "INFO" },
            { "OFF", "OFF" },
            { "SEVERE", "SCHWERWIEGEND" },
            { "WARNING", "WARNUNG" },
        };
    }
}
