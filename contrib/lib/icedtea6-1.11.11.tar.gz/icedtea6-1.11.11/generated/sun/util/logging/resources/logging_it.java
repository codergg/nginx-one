package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_it extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "TUTTO" },
            { "CONFIG", "CONFIG" },
            { "FINE", "FINE" },
            { "FINER", "MOLTO FINE" },
            { "FINEST", "FINISSIMO" },
            { "INFO", "INFO" },
            { "OFF", "OFF" },
            { "SEVERE", "GRAVE" },
            { "WARNING", "AVVERTENZA" },
        };
    }
}
