package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_zh_HK extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "ALL", "\u6240\u6709" },
            { "CONFIG", "\u914D\u7F6E" },
            { "FINE", "\u7D30\u7DFB" },
            { "FINER", "\u66F4\u7D30\u7DFB" },
            { "FINEST", "\u6700\u7D30\u7DFB" },
            { "INFO", "\u8CC7\u8A0A" },
            { "OFF", "\u95DC\u9589" },
            { "SEVERE", "\u56B4\u91CD\u7684" },
            { "WARNING", "\u8B66\u544A" },
        };
    }
}
