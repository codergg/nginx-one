package sun.awt.X11;
public class XAWTIcon32_java_icon16_png {
public static int[] java_icon16_png = { 
0,0
}; }
