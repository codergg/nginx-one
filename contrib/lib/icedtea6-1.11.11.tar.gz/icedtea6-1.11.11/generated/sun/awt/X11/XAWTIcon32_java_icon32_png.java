package sun.awt.X11;
public class XAWTIcon32_java_icon32_png {
public static int[] java_icon32_png = { 
0,0
}; }
