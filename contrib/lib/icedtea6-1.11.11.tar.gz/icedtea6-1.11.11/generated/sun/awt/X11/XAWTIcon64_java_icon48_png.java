package sun.awt.X11;
public class XAWTIcon64_java_icon48_png {
public static long[] java_icon48_png = { 
0,0
}; }
