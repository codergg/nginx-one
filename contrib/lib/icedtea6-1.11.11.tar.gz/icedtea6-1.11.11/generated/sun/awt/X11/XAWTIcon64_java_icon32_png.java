package sun.awt.X11;
public class XAWTIcon64_java_icon32_png {
public static long[] java_icon32_png = { 
0,0
}; }
